<?php
  $page_title = 'Admin página de inicio';
  require_once('includes/load.php');
  // Validación de permiso de acceso a la página
   page_require_level(3);
?>
<?php
 $c_inv_añadido  = count_by_cod_dispositivo('dispositivo',5,'=');
 $c_inc_resueltas  = count_by_id_estado('incidencia',5,'=');
 $c_user          = count_by_id('usuarios');
 $incidencias_por_tipo = incidencias_por_tipo('5');
 $incidencias_por_area = incidencias_por_area('5');
 $ultimas_incidencias    = ultimas_incidencias('5');
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
   <div class="col-md-6">
     <?php echo display_msg($msg); ?>
   </div>
</div>
  <div class="row">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-blue">
          <i class="glyphicon glyphicon-user"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_user['total']; ?> </h2>
          <p class="text-muted">Usuarios</p>
        </div>
       </div>
    </div>
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-blue">
          <i class="glyphicon glyphicon-warning-sign"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_inv_añadido['total']; ?> </h2>
          <p class="text-muted">Dispositivos</p>
        </div>
       </div>
    </div>
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-green">
          <i class="glyphicon glyphicon-ok"></i>
        </div>
        <div class="panel-value pull-right">
        <h2 class="margin-top"> <?php  echo $c_orden_pendientes['total']; ?></h2>
        <p class="text-muted">Dispositivos en inventario</p>
        </div>
       </div>
    </div>
</div>

  <div class="row">
   <div class="col-md-3">
     <div class="panel panel-default">
       <div class="panel-heading">
         <strong>
           <span class="glyphicon glyphicon-bookmark"></span>
           <span>Dispositivos por tipo</span>
         </strong>
       </div>
       <div class="panel-body">
         <table class="table table-striped table-bordered table-condensed">
          <thead>
           <tr>
             <th class="text-center">Tipo</th>
             <th class="text-center">Total Dispositivos</th>
             
           <tr>
          </thead>
          <tbody>
            <?php foreach ($incidencias_por_tipo as  $inc): ?>
              <tr>
                <td><?php echo remove_junk($inc['tipo']); ?></td>
                <td class="text-center"><?php echo (int)$inc['total']; ?></td>
                
              </tr>
            <?php endforeach; ?>
          <tbody>
         </table>
       </div>
     </div>
   </div>
   <div class="col-md-3">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-map-marker"></span>
            <span>Dispositivos por Zonas</span>
          </strong>
        </div>
        <div class="panel-body">
          <table class="table table-striped table-bordered table-condensed">
       <thead>
         <tr>
           
           <th class="text-center">Signatura</th>
           <th class="text-center">Nombre</th>
           <th class="text-center">Total Incidencias</th>
         </tr>
       </thead>
       <tbody>
         <?php foreach ($incidencias_por_area as  $inc): ?>
         <tr>
           <td><?php echo remove_junk($inc['signatura']); ?></td>
           <td><?php echo remove_junk($inc['nombre']); ?></td>
           <td class="text-center"><?php echo remove_junk($inc['total']); ?></td>
        </tr>

       <?php endforeach; ?>
       </tbody>
     </table>
    </div>
   </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-bell"></span>
          <span>Últimos Dispositivos añadidos</span>
        </strong>
      </div>
      <div class="panel-body">
          <table class="table table-striped table-bordered table-condensed">
       <thead>
         <tr>
           
           <th class="text-center">Fecha</th>
           <th class="text-center">Descripción</th>
           <th class="text-center">Prioridad</th>
         </tr>
       </thead>
       <tbody>
         <?php foreach ($ultimas_incidencias as  $inc): ?>
         <tr>
           <td><?php echo remove_junk($inc['fecha_incidencia']); ?></td>
           <td><?php echo remove_junk($inc['descripcion']); ?></td>
           <?php $pri=Dame_Prioridad($inc['prioridad']); ?>
           <td class="text-center"><?php echo remove_junk($pri); ?></td>
        </tr>

       <?php endforeach; ?>
       </tbody>
     </table>
    </div>
 </div>
</div>
</table>
</div>
 </div>
  <div class="row">

  </div>



<?php include_once('layouts/footer.php'); ?>
