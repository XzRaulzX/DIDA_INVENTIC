<?php
  $page_title = 'Administrar Inventario';
  require_once('includes/load.php');
  // Nivel de GEstor TIC (2)
   page_require_level(2);
  $incidencias = find_all_incidencias();
  
 
?>
<?php include_once('layouts/header.php'); ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <strong>
          <span class="glyphicon glyphicon-exclamation-sign"></span>
          <span>Inventario</span>
       </strong>
          <!--
         <div class="pull-right">
           <a href="add_product.php" class="btn btn-primary">Agragar producto</a>
         </div>
       -->

        </div>
        <div class="panel-body">
          <table class="table table-bordered" name="tabla">
            <thead>
              <tr>
                
                <th class="text-center" style="width: 10%;"> Fecha Incidencias</th>
                <th class="text-center" style="width: 30%;"> Descripción </th>
                <th class="text-center" style="width: 5%;"> Tipo </th>
                <th class="text-center" style="width: 10%;"> Lugar </th>
                <th class="text-center" style="width: 5%;"> Prioridad </th>
                <th class="text-center" style="width: 8%;"> Estado </th>
                <th class="text-center" style="width: 7%;"> Asignada a ... </th>
                <th class="text-center" style="width: 30%;"> Acciones </th>
              </tr>
            </thead>
            
            <tbody>
              <?php foreach ($incidencias as $inc):?>
              <tr>
               
                <!-- Estado de la incidencia  -->
                <?php $color_estado=$inc['estado'];
                  switch($color_estado) {
                    case 0: $color="generada"; $estado="generada";break;
                    case 1: $color="en_revision"; $estado="en revisión"; break;
                    case 2:  $color="confirmada"; $estado="confirmada"; break;
                    case 3: $color="en_reparacion"; $estado="en reparación"; break;
                    case 4:  $color="en_comprobacion"; $estado="en comprobación"; break;
                    case 5:  $color="finalizada"; $estado="finalizada"; break;                    
                    default: $color="generada";  };?>

                 <!-- Prioridad de la incidencia  -->
                <?php $prioridad=$inc['prioridad'];
                  switch($prioridad) {
                    case 0: $p_color="p_ninguna"; $p_prioridad="ninguna";break;
                    case 1: $p_color="p_baja"; $p_prioridad="BAJA"; break;
                    case 2:  $p_color="p_media"; $p_prioridad="MEDIA"; break;
                    case 3: $p_color="p_alta"; $p_prioridad="ALTA"; break;
                                   
                    default: $p_color="ninguna";  };?>




                <td class="text-center"> <?php echo remove_junk($inc['fecha_incidencia']); ?></td>
                <td> <?php echo remove_junk($inc['descripcion']); ?></td>
                <td class="text-center"> <?php echo remove_junk($inc['tipo_incidencia']); ?></td>
                <td class="text-center"> <?php echo remove_junk($inc['area']); ?></td>
                <td class=<?php echo $p_color ?>> <?php echo $p_prioridad; ?></td>
                <td class=<?php echo $color ?>> <?php echo $estado; ?></td>

               
 <!-- Busca al Técnico en la tabla de usuarios-->
                <?php 
                   
                    $tecnico=find_by_id('usuarios',$inc['id_tecnico']);?>
                 <td class="text-center" name="tecnico"> <?php echo remove_junk($tecnico['nombre']); ?></td>


                <td class="text-center">
                  <div class="btn-group">
                    <a href="asigna_prioridad.php?id=<?php echo (int)$inc['id'];?>" class="btn btn btn-prioridad"  title="Asigna Prioridad" data-toggle="tooltip">                     
                    Prioridad
                    </a>
                    <a href="asigna_estado.php?id=<?php echo (int)$inc['id'];?>" 
                        <?php
                        $tareasfina=cuenta_tareas($inc['id']);

                         if ($tareasfina['total']>0)
                         {
                          echo 'class="btn btn btn-estadoa"';
                         }

                         else 
                         {
                          echo 'class="btn btn btn-estado"';
                         }
                        ?>
                       title="Cambia Estado" data-toggle="tooltip"
                        <?php
                          if ($tecnico=="")
                            {
                            echo 'disabled="true"';
                            }
                          ?>
                        >
                      Estado
                    </a>

                    <a href="asigna_tecnico.php?id=<?php echo (int)$inc['id'];?>" class="btn btn btn-tecnico"  title="Asigna Técnico" data-toggle="tooltip"
                      <?php
                      $tecnicos=find_all_tecnicos();

                      if (empty($tecnicos))
                            {
                            echo 'disabled="true"';
                            }
                      ?>
                      >
                      Técnico
                    </a>
                    <a href="asigna_tarea.php?id=<?php echo (int)$inc['id'];?>" class="btn btn btn-tarea"  title="Crear Órdenes de Trabajo (Tareas) " data-toggle="tooltip">
                      Tareas
                    </a>
                    <a href="delete_incidencia.php?id=<?php echo (int)$inc['id'];?>" class="btn btn-danger btn-xs"  title="Eliminar" data-toggle="tooltip" 
                    <?php
                    if($tareasfina['total']>0)
                    {
                        echo 'disabled="true"';
                    }
                    ?>
                    >
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
             <?php endforeach; ?>
            </tbody>
         
          </table>
        </div>
      </div>
    </div>
  </div>
  <?php include_once('layouts/footer.php'); ?>
