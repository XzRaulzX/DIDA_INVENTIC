﻿
DROP TABLE IF EXISTS `id13658899_adadi`.`grupos_usuario`;
CREATE TABLE  `id13658899_adadi`.`grupos_usuario` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_grupo` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel_grupo` int(11) unsigned NOT NULL,
  `estado_grupo` int(1) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `nivel` (`nivel_grupo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`tipos_incidencia`;
CREATE TABLE  `id13658899_adadi`.`tipos_incidencia` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`usuarios`;
CREATE TABLE  `id13658899_adadi`.`usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clave` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nivel` int(11) unsigned NOT NULL,
  `estado` int(1) unsigned NOT NULL,
  `imagen` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'sin_imagen.png',
  `correo` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ultima_entrada` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `nivel` (`nivel`),
  CONSTRAINT `FK_usuarios_1` FOREIGN KEY (`nivel`) REFERENCES `grupos_usuario` (`nivel_grupo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`areas`;
CREATE TABLE  `id13658899_adadi`.`areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signatura` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ubicacion` int(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_areas_1` (`ubicacion`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`incidencia`;
CREATE TABLE  `id13658899_adadi`.`incidencia` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_incidencia` datetime NOT NULL,
  `fecha_resuelta` datetime DEFAULT NULL,
  `prioridad` int(1) unsigned DEFAULT '0',
  `estado` int(1) unsigned NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `id_area` int(10) unsigned NOT NULL,
  `id_tipo_incidencia` int(10) unsigned NOT NULL,
  `id_tecnico` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_incidencia_area` (`id_area`),
  KEY `FK_incidencia_tipo_inc` (`id_tipo_incidencia`),
  KEY `FK_incidencia_tecnico` (`id_tecnico`),
  KEY `FK_incidencia_usuario` (`id_usuario`),
  CONSTRAINT `FK_incidencia_area` FOREIGN KEY (`id_area`) REFERENCES `areas` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_incidencia_tecnico` FOREIGN KEY (`id_tecnico`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_incidencia_tipo_inc` FOREIGN KEY (`id_tipo_incidencia`) REFERENCES `tipos_incidencia` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_incidencia_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`orden_trabajo`;
CREATE TABLE  `id13658899_adadi`.`orden_trabajo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `estado` int(1) unsigned NOT NULL,
  `id_incidencia` int(10) unsigned NOT NULL,
  `tipo_actuacion` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(R)eparacion (S)ustitucion(C)ompra(I)nstalacion(E)liminacion',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_orden_trabajo_incidencia` (`id_incidencia`),
  CONSTRAINT `FK_orden_trabajo_incidencia` FOREIGN KEY (`id_incidencia`) REFERENCES `incidencia` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
DROP TABLE IF EXISTS `id13658899_adadi`.`media`;
CREATE TABLE  `id13658899_adadi`.`media` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
