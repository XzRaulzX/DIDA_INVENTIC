﻿insert into grupos_usuario
(id, nombre_grupo, nivel_grupo, estado_grupo)
values
(1, 'Super', 0, 1),
(2, 'Profesor', 1, 1),
(3, 'Gestor TIC', 2, 1),
(4, 'Técnico', 3, 1);
INSERT INTO USUARIOS
(id, nombre, usuario, clave, nivel, estado, correo)
VALUES
(1, 'Administrador SuperUsuario', 'Super', '363eb224f6ff8d3c5163a8805222acbf939a65b3', 0, 1, 'iesdiegoangulo.tic@gmail.com');