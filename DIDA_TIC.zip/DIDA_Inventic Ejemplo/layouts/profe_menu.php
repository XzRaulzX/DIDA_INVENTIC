<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  
   <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-exclamation-sign"></i>
      <span>INCIDENCIAS</span>
    </a>
    <ul class="nav submenu">      
       <li><a href="add_incidencia.php">Generar Incidencia</a> </li>
   </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-print"></i>
       <span>INFORMES</span>
      </a>
     <ul class="nav submenu">
        <li><a href="informe_incidencias.php">Incidencias </a></li>
        <li><a href="informe_tareas.php">Tareas</a></li>
     
      </ul>
  </li>
</ul>