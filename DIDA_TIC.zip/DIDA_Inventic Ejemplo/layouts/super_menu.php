<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>ACCESOS</span>
    </a>
    <ul class="nav submenu">
      <li><a href="grupos_usuario.php">Grupos</a> </li>
      <li><a href="usuarios.php">Usuarios</a> </li>
   </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-map-marker"></i>
      <span>ZONAS</span>
    </a>
    <ul class="nav submenu">
       <li><a href="areas.php">Administrar Zonas</a> </li>
       
   </ul>
  </li>
   <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-exclamation-sign"></i>
      <span>INVENTARIO</span>
    </a>
    <ul class="nav submenu">
       <li><a href="administrar_dispositivo.php">Administrar Dispositivos</a> </li>
       <li><a href="inventario.php">Administrar Inventario</a> </li>
       <!--<li><a href="add_incidencia.php">Generar Incidencia</a> </li>-->
   </ul>
  </li>

  <!--
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Media</span>
    </a>
  </li>
  -->
  
  <li>
   <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-wrench"></i>
       <span>UTILIDADES</span>
      </a>
      <ul class="nav submenu">
        <li><a href="importar_profesorado.php">Importar profesorado </a></li>
        <li><a href="lista_usuarios.php">Listado Profesorado / Claves </a></li>
        <li><a href="enviar_info.php">Enviar Información Usuario </a></li>
       
     
      </ul>
  </li>
</ul>
