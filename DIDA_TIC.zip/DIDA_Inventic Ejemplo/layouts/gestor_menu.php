<ul>
  <li>
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  
   <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-exclamation-sign"></i>
      <span>INCIDENCIAS</span>
    </a>
    <ul class="nav submenu">
       <li><a href="incidencia.php">Administrar incidencia</a> </li>
      
   </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-tasks"></i>
      <span>TAREAS</span>
    </a>
    <ul class="nav submenu">
       <li><a href="tarea.php">Administrar Tarea</a> </li>
      
   </ul>
  </li>
  <!--
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Media</span>
    </a>
  </li>
  -->
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-print"></i>
       <span>INFORMES</span>
      </a>
      <ul class="nav submenu">
        <li><a href="informe_incidencias.php">Incidencias </a></li>
        <li><a href="informe_tareas.php">Tareas</a></li>
     
      </ul>
  </li>
  <li>
   <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-wrench"></i>
       <span>UTILIDADES</span>
      </a>
      <ul class="nav submenu">
        <li><a href="importar_profesorado.php">Importar profesorado </a></li>
         <li><a href="lista_usuarios.php">Listado Profesorado / Claves </a></li>
        <li><a href="enviar_info.php">Enviar Información Usuario </a></li>
       
     
      </ul>
  </li>
</ul>
