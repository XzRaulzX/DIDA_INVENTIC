<div class="row">
  <div class="col-md-4">
   <div class="panel-footer">
             <strong>
                 <span class="glyphicon glyphicon-exclamation-sign"></span>
                 <span>IES Diego Angulo 2021</span>
             </strong>

             <strong>
                <span class="col-md-4">Realizado por: ALUMNOS DE 2º DE CICLO DE INFORMÁTICA DIEGO ANGULO.</span>
                <span class="col-md-4">Actualizado por: Raul Antonio Serra</span> 
             </strong>

             <strong>
                <span class="col-md-4"><a href="version.php" target="_blank">Versión</a></span>
             </strong>
    </div>
  </div>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" src="libs/js/functions.js"></script>

  </body>
  
  	 
</html>

<?php if(isset($db)) { $db->db_disconnect(); } ?>
