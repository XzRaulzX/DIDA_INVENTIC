<?php
/*
|--------------------------------------------------------------------------
| ADADI V 1.0
|--------------------------------------------------------------------------
| Author: Grupo FCT Programación
| Project Name: ADADI
| Version: v1
| Offcial page: (pendiente de subir)
|
|
|
*/
  define( 'DB_HOST', 'localhost' );          //  database host (deberá ser la IP del servidor hosting gratuito)
  define( 'DB_USER', 'root' );             //  database usuario
  define( 'DB_PASS', '' );             //  database password
  define( 'DB_NAME', 'dida_inventic' );        //  database nombre del esquema

?>