<?php
  require_once('includes/load.php');
  // Validación de permiso de acceso a la página
   page_require_level(0);
?>
<?php
  $delete_id = delete_by_id('incidencia',(int)$_GET['id']);
  if($delete_id){
      $session->msg("s","Tipo de Incidencia eliminada");
      redirect('incidencia.php');
  } else {
      $session->msg("d","Error eliminando Tipo de incidencia");
      redirect('incidencia.php');
  }
?>